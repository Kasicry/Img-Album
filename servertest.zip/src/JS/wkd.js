
const input = document.querySelector('input');
const preview = document.querySelector('.file_list');



